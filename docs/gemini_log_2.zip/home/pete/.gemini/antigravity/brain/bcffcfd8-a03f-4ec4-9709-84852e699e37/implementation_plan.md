# Implementation Plan - Fix Tool Argument Parsing

## Goal Description
Fix argument parsing issues in `ppt_add_bullet_list.py` and `ppt_add_text_box.py` where strict validation fails against Agent K2's usage pattern. The agent often omits `--size` or puts size information in `--position`. The fix involves making `--size` optional and intelligently extracting dimensions from `--position` if needed.

## User Review Required
> [!NOTE]
> This change relaxes the strict## Fix 3: Agent K2 Tool Argument Errors (Round 2)
### Problem
`ppt_add_bullet_list.py` and `ppt_add_text_box.py` failed due to strict argument parsing (missing `--size` or size in `--position`).

### Proposed Changes
#### [MODIFY] [ppt_add_bullet_list.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_bullet_list.py)
- Make `--size` optional.
- Merge dimensions from `--position` if missing in `--size`.

#### [MODIFY] [ppt_add_text_box.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_text_box.py)
- Make `--size` optional.
- Merge dimensions from `--position` if missing in `--size`.

### Verification Plan
- Create `repro_k2_round2.py` to simulate the failing calls.
- Verify successful execution.

## Fix 4: Agent K2 Tool Argument Errors (Round 3)
### Problem
1. `ppt_add_shape.py` and `ppt_add_chart.py`: `ValueError: Size must have at least width or height`.
2. `ppt_add_text_box.py`: `unrecognized arguments: true` (boolean flag misuse).
3. `ppt_set_footer.py`: `unrecognized arguments: true false` (boolean flag misuse).

### Proposed Changes
#### [MODIFY] [ppt_add_shape.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_shape.py)
- Make `--size` optional.
- Merge dimensions from `--position` if missing in `--size`.

#### [MODIFY] [ppt_add_chart.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_chart.py)
- Make `--size` optional.
- Merge dimensions from `--position` if missing in `--size`.

#### [MODIFY] [ppt_add_text_box.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_text_box.py)
- Update `--bold` and `--italic` to accept optional string values (e.g., "true", "false").

#### [MODIFY] [ppt_set_footer.py](file:///home/project/powerpoint-agent-tools/tools/ppt_set_footer.py)
- Update `--show-number` and `--show-date` to accept optional string values.

### Verification Plan
- Create `repro_k2_round3.py` to simulate the failing calls.
- Verify successful execution.

## Fix 5: Agent K2 Tool Argument Errors (Round 4)
### Problem
Errors persist on Slide 10 because the agent omits dimensions entirely (or partially) from both `--size` and `--position`.
- `ppt_add_text_box.py`: `ValueError: Text box must have explicit width and height`
- `ppt_add_shape.py`: `ValueError: Size must have at least width or height`

### Proposed Changes
Implement default dimensions if missing in both `--size` and `--position`.

#### [MODIFY] [ppt_add_text_box.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_text_box.py)
- If `width` missing: default to "40%"
- If `height` missing: default to "20%"

#### [MODIFY] [ppt_add_shape.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_shape.py)
- If `width` missing: default to "20%"
- If `height` missing: default to "20%"

#### [MODIFY] [ppt_add_chart.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_chart.py)
- If `width` missing: default to "50%"
- If `height` missing: default to "50%"

#### [MODIFY] [ppt_add_bullet_list.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_bullet_list.py)
- If `width` missing: default to "80%"
- If `height` missing: default to "50%"

### Verification Plan
- Create `repro_k2_round4.py` simulating calls with NO dimensions.
- Verify successful execution.

#### [MODIFY] [ppt_add_text_box.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_text_box.py)
- Make `--size` optional in `argparse` (remove `required=True`).
- In `main()`:
    - Initialize `args.size` to `{}` if None.
    - Check if `width` and `height` exist in `args.position`.
    - If present in position but missing in size, copy them to `args.size`.

## Verification Plan

### Automated Tests
- Create a test script `repro_k2_round2.py` that calls the tools with the problematic arguments (missing size, or size in position).
- Verify that the tools execute successfully and the elements are added with correct dimensions.

### Manual Verification
- Run `agent_k2.sh` (or the relevant parts) to ensure it proceeds past the previous failure points.
