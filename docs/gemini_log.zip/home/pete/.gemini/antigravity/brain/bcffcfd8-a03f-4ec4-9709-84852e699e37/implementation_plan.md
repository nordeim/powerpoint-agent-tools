# Implementation Plan - Fix Tool Argument Parsing

## Goal Description
Fix argument parsing issues in `ppt_add_bullet_list.py` and `ppt_add_text_box.py` where strict validation fails against Agent K2's usage pattern. The agent often omits `--size` or puts size information in `--position`. The fix involves making `--size` optional and intelligently extracting dimensions from `--position` if needed.

## User Review Required
> [!NOTE]
> This change relaxes the strict argument requirements of the CLI tools to accommodate the agent's behavior. It improves robustness without changing the core logic.

## Proposed Changes

### Tools

#### [MODIFY] [ppt_add_bullet_list.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_bullet_list.py)
- Make `--size` optional in `argparse` (remove `required=True`).
- In `main()`:
    - Initialize `args.size` to `{}` if None.
    - Check if `width` and `height` exist in `args.position`.
    - If present in position but missing in size, copy them to `args.size`.

#### [MODIFY] [ppt_add_text_box.py](file:///home/project/powerpoint-agent-tools/tools/ppt_add_text_box.py)
- Make `--size` optional in `argparse` (remove `required=True`).
- In `main()`:
    - Initialize `args.size` to `{}` if None.
    - Check if `width` and `height` exist in `args.position`.
    - If present in position but missing in size, copy them to `args.size`.

## Verification Plan

### Automated Tests
- Create a test script `repro_k2_round2.py` that calls the tools with the problematic arguments (missing size, or size in position).
- Verify that the tools execute successfully and the elements are added with correct dimensions.

### Manual Verification
- Run `agent_k2.sh` (or the relevant parts) to ensure it proceeds past the previous failure points.
